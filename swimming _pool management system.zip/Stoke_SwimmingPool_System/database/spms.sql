-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 18, 2022 at 01:47 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `ad_uname` varchar(150) NOT NULL,
  `ad_pwd` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `ad_uname`, `ad_pwd`) VALUES
(1, 'admin', '1234'),
(2, 'jasmy', '123jasmy');

-- --------------------------------------------------------

--
-- Table structure for table `coach`
--

CREATE TABLE `coach` (
  `id` int(11) NOT NULL,
  `coach_name` varchar(150) NOT NULL,
  `coach_pwd` varchar(150) NOT NULL,
  `coach_email` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `coach`
--

INSERT INTO `coach` (`id`, `coach_name`, `coach_pwd`, `coach_email`) VALUES
(1, 'Eric', '123eric', 'eric@gmail.com'),
(2, 'Anju', '123anju', 'anju@gmail.com'),
(3, 'anju', '123', 'anju@gmail.com'),
(4, 'des', '123', 'des@gmail.com'),
(5, 'athu', 'qwerty', 'athu@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `Event_name` varchar(150) NOT NULL,
  `Event_place` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `Event_name`, `Event_place`) VALUES
(13, 'North Midland Swimming Race', 'South Wales'),
(14, 'Northern Ireland Swimming Race', 'Southampton'),
(15, 'Stoke Swimming Gala', 'Birmingham');

-- --------------------------------------------------------

--
-- Table structure for table `event_reg`
--

CREATE TABLE `event_reg` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `dob` date NOT NULL,
  `stroke` varchar(150) NOT NULL,
  `place` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `event_reg`
--

INSERT INTO `event_reg` (`id`, `name`, `dob`, `stroke`, `place`) VALUES
(2, 'jincy', '2022-05-12', 'Butterfly', 'birmingham'),
(3, 'jincy', '2022-05-12', 'Butterfly', 'birmingham'),
(4, 'ray', '2022-05-19', 'Breast', 'manchester');

-- --------------------------------------------------------

--
-- Table structure for table `gala`
--

CREATE TABLE `gala` (
  `id` int(11) NOT NULL,
  `Gala_name` varchar(150) NOT NULL,
  `swimmer_name` varchar(150) NOT NULL,
  `result` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gala`
--

INSERT INTO `gala` (`id`, `Gala_name`, `swimmer_name`, `result`) VALUES
(9, 'North midland', 'antony', 'First');

-- --------------------------------------------------------

--
-- Table structure for table `parents`
--

CREATE TABLE `parents` (
  `id` int(11) NOT NULL,
  `parent_name` varchar(150) NOT NULL,
  `parent_pass` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `parents`
--

INSERT INTO `parents` (`id`, `parent_name`, `parent_pass`) VALUES
(1, 'bose', '123bose');

-- --------------------------------------------------------

--
-- Table structure for table `perfomance`
--

CREATE TABLE `perfomance` (
  `id` int(11) NOT NULL,
  `ath_name` varchar(150) NOT NULL,
  `age` int(150) NOT NULL,
  `rank` int(150) NOT NULL,
  `exec` decimal(15,0) NOT NULL,
  `style` varchar(150) NOT NULL,
  `stroke` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `perfomance`
--

INSERT INTO `perfomance` (`id`, `ath_name`, `age`, `rank`, `exec`, `style`, `stroke`) VALUES
(6, 'arthur', 19, 1, '20', 'solo', 'Breaststroke');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `id` int(11) NOT NULL,
  `cad_type` varchar(150) NOT NULL,
  `cad_time` date NOT NULL,
  `cad_pre` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`id`, `cad_type`, `cad_time`, `cad_pre`) VALUES
(3, 'Adults', '2022-05-27', 'Outdoor'),
(4, 'Adults', '2022-05-27', 'Mainpool');

-- --------------------------------------------------------

--
-- Table structure for table `swimmers`
--

CREATE TABLE `swimmers` (
  `id` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `middle_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `age` int(150) NOT NULL,
  `gender` varchar(150) NOT NULL,
  `phone` varchar(150) NOT NULL,
  `cur_address` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `pwd` varchar(150) NOT NULL,
  `conf_pwd` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `swimmers`
--

INSERT INTO `swimmers` (`id`, `first_name`, `middle_name`, `last_name`, `age`, `gender`, `phone`, `cur_address`, `email`, `pwd`, `conf_pwd`) VALUES
('', 'jasmy ', 'p', 'bose', 0, 'Female', '07423552854', '15 Liddle Street\r\n\r\nunited kingdom', 'jasmy.bose@gmail.com', '1234', '1234'),
('', 'june', 'art', 'wooley', 0, 'Female', '07423552854', '  21 woodhouse stret\r\n', 'june@gmail.com', '1234', '1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coach`
--
ALTER TABLE `coach`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event_reg`
--
ALTER TABLE `event_reg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gala`
--
ALTER TABLE `gala`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parents`
--
ALTER TABLE `parents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `perfomance`
--
ALTER TABLE `perfomance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `coach`
--
ALTER TABLE `coach`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `event_reg`
--
ALTER TABLE `event_reg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `gala`
--
ALTER TABLE `gala`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `parents`
--
ALTER TABLE `parents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `perfomance`
--
ALTER TABLE `perfomance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
