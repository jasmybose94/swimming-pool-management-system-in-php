<?php
include("db.php");

session_start();
 
?>
<!DOCTYPE html>
<html>
    <head>
        <title> welcome to stokepool </title>
        <link rel = "stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<?php include("navibar.php"); 

 ?> 
    <div id="section">
 
        <div id="content">
            <h3 class= text> Events Registered</h3><br><br>
            <div class="tbox">
    <h3> Swimmers Registered Event Details</h3>
    
    <table border="1px">   
<tr>
<th>s.no</th>
<th>Swimmer name</th>
<th>Event Date</th>
<th>Stroke Type</th>
<th> place</th>
</tr>
<?php  
   $s="SELECT * FROM event_reg";
    $res=$db->query($s);
    if($res->num_rows>0){
        $i=0;
        while($r=$res->fetch_assoc()){
            $i++;
            echo"<tr>
           <td> {$i}         </td> 
           <td>  {$r["name"]}     </td> 
           <td>  {$r["dob"]}       </td> 
           <td>  {$r["stroke"]}       </td> 
           <td>  {$r["place"]}       </td> 
          
                
            
            </tr>";


        }
    }

    ?>




    </table>
