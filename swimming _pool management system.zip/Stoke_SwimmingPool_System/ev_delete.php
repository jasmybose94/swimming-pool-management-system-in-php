<?php

include"db.php";
session_start();
$s="delete from events where id={$_GET["id"]}";
$db->query($s);
echo"<script> window.open('events.php?mes=Result deleted','_self');</script>";
?>