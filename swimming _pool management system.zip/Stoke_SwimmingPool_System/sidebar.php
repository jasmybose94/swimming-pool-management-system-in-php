<div class="sidebar">
    <h3 class="text">Dashboard </h3><br><hr><br>
    <ul class="side"> 
        <?php
        
if(isset($_SESSION["id"])){
    echo'
    
    <li class="li"><a href="admin_dashboard.php"> Club Information </a> </li>
    <li class="li"><a href="add_coach.php"> Addcoach </a> </li>
    <li class="li"><a href="events.php"> Upcoming Events </a> </li>
    <li class="li"><a href="gala.php"> Gala Results </a> </li>
    <li class="li"><a href="perfomance.php"> Weekly Perfomance</a> </li>
    <li class="li"><a href="event_regview.php"> Students Registered events</a> </li>
    

    

    
    ';

}
else{


    echo'

    <li class="li"><a href=""> </a> </li>
    <li class="li"><a href="">  </a> </li>
    <li class="li"><a href="">  </a> </li>
    

     
    
    
    ';
}






        ?>






    </ul>


</div>
