<?php
include("db.php");
session_start();
 ?>
<!DOCTYPE html>
<html>
    <head>
        <title> welcome to stokepool </title>
        <link rel = "stylesheet" type="text/css" href="css/style.css">
</head>
<body>
</body>
<div id="content">
            <h3 class= text> Event Registration</h3><br><br>

            <?php

if(isset($_POST["submit"])){
    
    $name=$_POST['ename'];
    $dob=$_POST['dob'];
    $str=$_POST['stroke']; 
    $place=$_POST['place'];
   
    $sql="INSERT INTO event_reg(name,dob,stroke,place) VALUES('$name','$dob','$str','$place')";
    if(mysqli_query($db,$sql)){
        echo"<div class='sucess'>Event Registered Succesfully</div>";
}
else 
{
    echo"<div class= 'error'><h3> Registration Failed</h3> </div>";
}

}
?>
         
<form  class= "text" method="POST" action="<?php echo($_SERVER["PHP_SELF"]); ?>">
<label>Candidate name </label> <br>  
<input type="text" name="ename" placeholder= "name"  required class="input2" />  <br> <br>
            <label>Event Date </label><br>
        <input type="Date" name="dob" required class="input2"><br>
        <label> Stroke Type</label><br>
            <select name="stroke" required class="input2">
            <option value="">select</option>
            <option value="Butterfly">Butterfly</option>
            <option value="Back">Back</option>
            <option value="Breast">Breast</option>
      </select>  <br>
      <label>Event Place </label> <br>  
<input type="text" name="place" placeholder= "name"  required class="input2" /> <br>
      <button type="submit" class="btn" name="submit"> Register </button> 

            </form>



</div>
</html>