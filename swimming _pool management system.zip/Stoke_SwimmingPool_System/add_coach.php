<?php
include("db.php");

session_start();
 
?>
<!DOCTYPE html>
<html>
    <head>
        <title> welcome to stokepool </title>
        <link rel = "stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<?php include("navigation_bar.php");  ?>

    <img src="image/admin.jpg" width="1200px"  class="sha">
    <div id="section">
    <?php include "sidebar.php" ;?>

        
        <div id="content">
            <h3 class= text> Welcome <?php echo $_SESSION["ad_uname"]; ?></h3><br><hr><br>
            <h3> Add Coach Details</h3><br>
<?php
 if(isset($_POST["submit"])){
    $sql="INSERT into coach(coach_name,coach_pwd,coach_email)values('{$_POST["sname"]}','{$_POST["spwd"]}','{$_POST["semail"]}')";
    if($db->query($sql)){
        echo"<div class='sucess'>Result Added Successsfuly</div>";


    }
    else{

        echo"<div class = 'error'> Insert failed</div>";

    }

}



?>
<form method="post" action="<?php echo($_SERVER["PHP_SELF"]); ?>">

<label> Coach Name </label><br>
<input type="text" name="sname" required class="input"><br>

<label> Coach Password</label><br>
<input type="password" name="spwd" required class="input"><br>

<label> Coach Email</label><br>
<input type="email" name="semail" required class="input"><br>

<button type="submit" class="btn" name="submit"> Add</button>






</form>





            </div>





</div>


    
<div class="footer">
    <footer><p>Stoke swimming pool </p></footer>
</div>
</body>
</html>