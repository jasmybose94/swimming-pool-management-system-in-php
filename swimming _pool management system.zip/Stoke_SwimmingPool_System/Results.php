<?php
include("db.php");

session_start();
 
?>
<!DOCTYPE html>
<html>
    <head>
        <title> welcome to stokepool </title>
        <link rel = "stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<div id="section">

<div id="content">
    <h3 class= text> Welcome to Results </h3><br><br>
    <h3 class="text"> Gala Results </h3><br><br>
<table  class ="text" border="1px">   
<tr>
<th>s.no</th>
<th>Gala name</th>
<th>swimmer name</th>
<th>Result</th>


</tr>
<?php
$s= "SELECT * from gala";
$res=$db->query($s);
if($res->num_rows>0){
    $i=0;
    while($r=$res->fetch_assoc()){
        $i++;
        echo"<tr>
        <td>{$i}  </td>
        <td>{$r["Gala_name"]}  </td>
        <td>{$r["swimmer_name"]}  </td>
        <td>{$r["result"]}  </td>
        
        
        
        
        
       </tr> ";


    }
}


?>
</table>


</body>


          
    