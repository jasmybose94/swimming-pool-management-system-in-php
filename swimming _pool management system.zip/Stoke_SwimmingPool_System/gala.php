<?php
include("db.php");

session_start();
 
?>


<!DOCTYPE html>
<html>
    <head>
        <title> welcome to stokepool </title>
        <link rel = "stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<?php include("navigation_bar.php");  ?>

    <img src="image/admin.jpg" width="1200px"  class="sha">
    <div id="section">
    <?php include "sidebar.php" ;?>

        
        <div id="content">
            <h3 class= text> Welcome <?php echo $_SESSION["ad_uname"]; ?></h3><br><hr><br>
            <h3> Gala Results</h3><br>
            <?php

            if(isset($_POST["submit"])){
                $sql="INSERT into gala(Gala_name,swimmer_name,result)values('{$_POST["gname"]}','{$_POST["sname"]}','{$_POST["res"]}')";
                if($db->query($sql)){
                    echo"<div class='sucess'>Result Added Successsfuly</div>";


                }
                else{

                    echo"<div class = 'error'> Insert failed</div>";
            
                }

            }
            ?>
           
           <form method="POST" ACTION="<?php echo$_SERVER["PHP_SELF"]; ?>">
           <label> Gala Name </label><br>
<input type="text" name="gname" required class="input"><br>

<label> Swimmer Name</label><br>
<input type="text" name="sname" required class="input"><br>

<label> Result</label><br>
<input type="text" name="res" required class="input"><br>

<button type="submit" class="btn" name="submit"> Add</button>
           </form>

           <h3> Results</h3>
           
           <div class="tbox">
   
    <?php

if(isset($_GET["mes"])){

    echo"<div class='error'>{$_GET["mes"]}</div>";
}
?>



    <table border="1px">   
<tr>
<th>s.no</th>
<th>Gala name</th>
<th>swimmer name</th>
<th>Result</th>
<th> delete</th>

</tr>
<?php
$s= "SELECT * from gala";
$res=$db->query($s);
if($res->num_rows>0){
    $i=0;
    while($r=$res->fetch_assoc()){
        $i++;
        echo"<tr>
        <td>{$i}  </td>
        <td>{$r["Gala_name"]}  </td>
        <td>{$r["swimmer_name"]}  </td>
        <td>{$r["result"]}  </td>
        <td><a href='ga_delete.php?id={$r["id"]}'class='btnr'> Delete </td> 
        
        
        
        
        
       </tr> ";


    }
}


?>





          
            
</div>


  




</div>





</div>


   
</body>
</html>