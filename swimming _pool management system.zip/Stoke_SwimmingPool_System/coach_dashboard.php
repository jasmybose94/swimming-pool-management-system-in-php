<?php
include("db.php");

session_start();
 
?>


<!DOCTYPE html>
<html>
    <head>
        <title> welcome to stokepool </title>
        <link rel = "stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<?php include("navibar.php"); 
include("coach_sidebar.php")
 ?> 
    <div id="section">
 
        <div id="content">
            <h3 class= text> Welcome <?php echo $_SESSION["coach_name"]; ?></h3><br><br>
            <h2 class="text"> Swimmers Perfomance</h2><br>

            <?php

if(isset($_POST["submit"])){


    $sql="INSERT into perfomance(Ath_name,age,rank,exec,style,stroke)values('{$_POST["aname"]}','{$_POST["age"]}','{$_POST["res"]}','{$_POST["exe"]}','{$_POST["sty"]}','{$_POST["str"]}')";
    if($db->query($sql) ){
        echo"<div class = 'sucess'> Perfomance added succesfully</div>";

    }else{

        echo"<div class = 'error'> Insert failed</div>";

    }
}
?>

            <form method="POST" ACTION="<?php echo$_SERVER["PHP_SELF"]; ?>">
           <label> Athelete Name </label><br><br>
  <input type="text" name="aname" required class="input"><br>
     <label> Age</label><br><br>
    <input type="text" name="age" required class="input"><br>
   <label> Rank</label><br>
   <input type="text" name="res" required class="input"><br>
   <label> Execution</label><br>
   <input type="text" name="exe" required class="input"><br>
   <label> style</label><br><br>
   <select name="sty" required class="input">
            <option value="">select</option>
            <option value="solo">solo</option>
            <option value="group">group</option>
      </select>  <br>
      <label>Stroke</label><br><br>
      <select name="str" required class="input">
            <option value="">select</option>
            <option value="Butterfly">Butterfly</option>
            <option value="Backstroke">Backstroke</option>
            <option value="Breaststroke">Breaststroke</option>
            <option value="Freestyle">Freestyle</option>
      </select>  <br>
   <button type="submit" class="btn" name="submit"> Add</button>
           </form>
           <div class="tbox">
    <h3> Perfomance Details</h3>
<?php

if(isset($_GET["mes"])){

    echo"<div class='error'>{$_GET["mes"]}</div>";
}
?>
    <table border="1px">   
<tr>
<th>s.no</th>
<th>Athelete name</th>
<th>Age</th>
<th>Executionk</th>
<th> Style</th>
<th> Stroke</th>
<th> Delete</th>




</tr>
<?php  
   $s="SELECT * FROM perfomance";
    $res=$db->query($s);
    if($res->num_rows>0){
        $i=0;
        while($r=$res->fetch_assoc()){
            $i++;
            echo"<tr>
           <td> {$i}         </td> 
           <td>  {$r["ath_name"]}     </td> 
           <td>  {$r["rank"]}       </td> 
           <td>  {$r["exec"]}       </td> 
           <td>  {$r["style"]}       </td>
           <td>  {$r["stroke"]}       </td>  
           
           
           <td><a href='perf_delete.php?id={$r["id"]}'class='btnr'> Delete </td> 
                
            
            
            
            
            </tr>";


        }
    }

    ?>




            

</div>





</div>


    
</div>
</body>
</html>