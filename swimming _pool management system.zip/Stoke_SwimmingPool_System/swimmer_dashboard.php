<?php
include("db.php");
session_start();
 ?>
<!DOCTYPE html>
<html>
    <head>
        <title> welcome to stokepool </title>
        <link rel = "stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<?php include("navibar.php");  ?>
<?php include("swim_sidebar.php");  ?>

<div id="section">
<div id="content">


<h2 class="text"> Schedule Training</h2><br>

<?php

if(isset($_POST["submit"])){


    $sql="INSERT into schedule(cad_type,cad_time,cad_pre)values('{$_POST["scedulename"]}','{$_POST["time"]}','{$_POST["scedulepref"]}')";
    if($db->query($sql) ){
        echo"<div class = 'sucess'> Scedule added succesfully</div>";

    }else{

        echo"<div class = 'error'> Insert failed</div>";

    }
}
?>






<form  class= "text" method="POST" action="<?php echo($_SERVER["PHP_SELF"]); ?>">
            <label>Candidate Type</label><br>
            <select name="scedulename" required class="input2">
            <option value="">select</option>
            <option value="Junior">Junior</option>
            <option value="Adults">Adults</option>
            <option value="womens">Womens</option>
            </select><br><br>
            <label> Time </label><br>
        <input type="Date" name="time" required class="input2"><br>
        <label> Pool Preference</label><br>
            <select name="scedulepref" required class="input2">
            <option value="">select</option>
            <option value="Indoor">Indoor</option>
            <option value="Outdoor">Outdoor</option>
            <option value="Mainpool">Main Pool</option>
      </select>  <br>
      <button type="submit" class="btn" name="submit"> Schedule </button> 

            </form>
            <div class="tbox">
    <h3> Schedule Details</h3>
<?php

if(isset($_GET["mes"])){

    echo"<div class='error'>{$_GET["mes"]}</div>";
}
?>



    <table border="1px">   
<tr>
<th>s.no</th>
<th>Candidate Type</th>
<th>Date</th>
<th> Pool Preference</th>
<th>  Delete</th>
</tr>
<?php  
   $s="SELECT * FROM schedule";
    $res=$db->query($s);
    if($res->num_rows>0){
        $i=0;
        while($r=$res->fetch_assoc()){
            $i++;
            echo"<tr>
           <td> {$i}         </td> 
           <td>  {$r["cad_type"]}     </td> 
           <td>  {$r["cad_time"]}       </td>
           <td>  {$r["cad_pre"]}       </td> 
           <td><a href='sc_delete.php?id={$r["id"]}'class='btnr'> Delete       </td> 
            
                
 
            </tr>";


        }
    }

    ?>




    </table>




</div>





</div>

            









    
<div class="footer">
    <footer><p>Stoke swimming pool </p></footer>
</div>
</body>
</html>