<?php
session_start();
include("db.php");

?>





<!DOCTYPE html>
<html>
    <head>
        <title> welcome to stokepool </title>
        <link rel = "stylesheet" type="text/css" href="css/style.css">
</head>
<body class="backgr">
<?php include("navigation_bar.php");  ?>

    <img src="image/bg_image.jpg" width="675">
    <div class="login">
        <h1 class="heading"> Coach Login </h1>
        <div class="logn">
        <?php
        if(isset($_POST["login"])){
            $sql="SELECT * from  coach where coach_name='{$_POST["cname"]}' and coach_pwd='{$_POST["cpass"]}'";
            $result= $db->query($sql);
            if($result->num_rows>0){
                $ar=$result->fetch_assoc();
                $_SESSION["id"]=$ar["id"];
                $_SESSION["coach_name"]=$ar["coach_name"];
                echo"<script> window.open('coach_dashboard.php','_self');</script>";
            }
            else{
                echo"<div class= 'error'>Invalid Username and Password </div>";
            }
        }

        ?>



            <form method="POST" action="">
                <label> Username</label>
                <input type="text" name="cname" required class= "input"><br>
                <label> Password</label>
                <input type="Password" name="cpass" required class="input"><br>
                <button type="submit" class="btn" name="login"> Login</button>


            </form>

</div>
</div>
<div class="footer">
    <footer><p>Stoke swimming pool </p></footer>
</div>
</body>
</html>