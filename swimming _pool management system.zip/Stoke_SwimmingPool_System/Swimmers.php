<?php
session_start();
include("db.php");
?>

<!DOCTYPE html>
<html>
    <head>
        <title> welcome to stokepool </title>
        <link rel = "stylesheet" type="text/css" href="css/style.css">
</head>
<body class="backgr">
<?php include("navigation_bar.php");  ?>

    <img src="image/bg_image.jpg" width="100%">
    <div class="login">
        <h1 class="heading"> Swimmers Login </h1>
        <div class="logn">
<?php
if(isset($_POST["login"])){
    $sql="SELECT * from  swimmers where email='{$_POST["uemail"]}' and pwd='{$_POST["upass"]}'";
    $result= $db->query($sql);
    if($result->num_rows>0){
        $ar=$result->fetch_assoc();
        $_SESSION["id"]=$ar["id"];
        $_SESSION["email"]=$ar["email"];
        
        echo"<script> window.open('swimmer_dashboard.php','_self');</script>";

    }
    else{
        echo"<div class= 'error'>Invalid Username and Password </div>";
    }
}



?>
            <form method="POST" action="">
                <label> UserEmail</label>
                <input type="email" name="uemail" required class= "input"><br>
                <label> Password</label>
                <input type="Password" name="upass" required class="input"><br>
                <button type="submit" class="btn" name="login"> Login</button><br>
                 not registered<a href="Swimmer_reg.php"> Sign up</a>
            </form>

</div>
</div>
<div class="footer">
    <footer><p>Stoke swimming pool </p></footer>
</div>
</body>
</html>