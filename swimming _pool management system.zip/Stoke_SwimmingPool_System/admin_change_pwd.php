<?php
include("db.php");

session_start();
 
?>
<!DOCTYPE html>
<html>
    <head>
        <title> welcome to stokepool </title>
        <link rel = "stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<div id="content">
            <h3 class= text> Welcome <?php echo $_SESSION["ad_uname"]; ?></h3><br><br>
            <h2 class= text> Change Password</h2><br><br>
<?php

if(isset($_POST['update']))
{    $username=$_POST['uname'];
    $oldpass=md5($_POST['old_pwd']);
    $newpassword=md5($_POST['new_pwd']);
    $sql=mysqli_query($db,"SELECT ad_pwd FROM admin where ad_pwd='$oldpass' && ad_uname='$username'");
     $num=mysqli_fetch_array($sql);
     if($num>0)
{
 $db=mysqli_query($db,"update admin set ad_pwd=' $newpassword' where ad_uname='$username'");
$_SESSION['msg1']="Password Changed Successfully !!";
}
else{
    $_SESSION['msg1']="Old Password not match !!";
}
}

?>
         
            <form  class = "text" method="POST" action="">
            <label>Enter Username</label><br>
                <input type="text" name="uname" required class= "input2"><br>
                <label>Enter Old Password</label><br>
                <input type="password" name="old_pwd" required class= "input2"><br>
                <label>Enter New Password</label><br>
                <input type="Password" name="new_pwd" required class="input2"><br>
                <label>Confirm Password</label><br>
                <input type="Password" name="conf_pwd" required class="input2"><br>
                

                <button type="submit" class="btn" name="update">Update</button>


            </form>
</div>