<?php
include("db.php");

session_start();
 
?>


<!DOCTYPE html>
<html>
    <head>
        <title> welcome to stokepool </title>
        <link rel = "stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<?php 
include("navigation_bar.php");  

?>

    <img src="image/admin.jpg" width="100%"  class="sha">
    <div id="section">
    <?php include "sidebar.php" ;?>

        
        <div id="content">
            <h3 class= text> Welcome <?php echo $_SESSION["ad_uname"]; ?></h3><br><hr><br>
            <h3> about the club</h3><br>
            <img src="image/img_content.png" class="imgs">
            <p class="para"> 
         We are one of Staffordshire’s premier competitive swimming clubs with swimmers frequently representing the club at County, Regional and National levels
        We are affiliated to Swim England, West Midlands Region and Staffordshire Amateur Swimming Association.
        The Club aims to provide opportunities for swimmers of all ages and abilities to reach their potential.
        Cosacss is a Swim Mark accredited club.  
            </p>
           

</div>





</div>


    
<div class="footer">
    <footer><p>Stoke swimming pool </p></footer>
</div>
</body>
</html>