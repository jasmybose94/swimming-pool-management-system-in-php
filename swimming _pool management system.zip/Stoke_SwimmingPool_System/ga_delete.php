<?php

include"db.php";
session_start();
$s="delete from gala where id={$_GET["id"]}";
$db->query($s);
echo"<script> window.open('gala.php?mes=Event deleted','_self');</script>";
?>