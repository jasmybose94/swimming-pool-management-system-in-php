<?php
include("db.php");

session_start();
 
?>


<!DOCTYPE html>
<html>
    <head>
        <title> welcome to stokepool </title>
        <link rel = "stylesheet" type="text/css" href="css/style.css">
</head>
<body>

<?php
include("navibar.php");
?>

    
    <div id="section">

        <div id="content">
            <h3 class= text> Welcome <?php echo $_SESSION["parent_name"]; ?></h3><br><br>
            <h3 class="text"> Upcoming Events </h3>
<?php   
 include("parent_sidebar.php") 
 ?>

 <table border="1px">   
 <tr>
 <th>s.no</th>
 <th>Event name</th>
 <th>Place</th>
 <th> Register</th>
 </tr>
 <?php  
   $s="SELECT * FROM events";
    $res=$db->query($s);
    if($res->num_rows>0){
        $i=0;
        while($r=$res->fetch_assoc()){
            $i++;
            echo"<tr>
           <td> {$i}         </td> 
           <td>  {$r["Event_name"]}     </td> 
           <td>  {$r["Event_place"]}       </td> 
           <td><a href='event_reg.php?id={$r["id"]}'class='btnr'> Register      </td> 
                
            
            
            
            
            </tr>";


        }
    }

    ?>




            </div>





</div>
    

</div>





</div>


    

</body>
</html>