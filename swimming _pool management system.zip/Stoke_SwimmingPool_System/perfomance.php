<?php
include("db.php");

session_start();
 
?>
<!DOCTYPE html>
<html>
    <head>
        <title> welcome to stokepool </title>
        <link rel = "stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<div id="section">
<div id="content">
<h2 class="text"> Swimmers Perfomance</h2><br>
<?php

if(isset($_GET["mes"])){

    echo"<div class='error'>{$_GET["mes"]}</div>";
}
?>
    <table border="1px">   
<tr>
<th>s.no</th>
<th>Athelete name</th>
<th>Age</th>
<th>Executionk</th>
<th> Style</th>
<th> Stroke</th>

</tr>
<?php  
   $s="SELECT * FROM perfomance";
    $res=$db->query($s);
    if($res->num_rows>0){
        $i=0;
        while($r=$res->fetch_assoc()){
            $i++;
            echo"<tr>
           <td> {$i}         </td> 
           <td>  {$r["ath_name"]}     </td> 
           <td>  {$r["rank"]}       </td> 
           <td>  {$r["exec"]}       </td> 
           <td>  {$r["style"]}       </td>
           <td>  {$r["stroke"]}       </td>  
           
           
     
            </tr>";


        }
    }

    ?>
          

</div>

</div>
    
</div>
</body>
</html>