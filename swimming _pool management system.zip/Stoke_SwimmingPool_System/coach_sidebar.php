<div class="sidebar">
    <h3 class="text">Dashboard </h3><br><hr><br>
    <ul class="side"> 
        <?php
        
if(isset($_SESSION["id"])){
    echo'
    
    
    <li class="li"><a href="event_regview.php"> Students Events Registered </a> </li>
    <li class="li"><a href="Results.php"> Gala Results </a> </li>
    
    
    

    

    
    ';

}
else{


    echo'

    <li class="li"><a href=""> </a> </li>
    <li class="li"><a href="">  </a> </li>
    <li class="li"><a href="">  </a> </li>
    

     
    
    
    ';
}






        ?>






    </ul>


</div>
