<?php

include"db.php";
session_start();
$s="delete from perfomance where id={$_GET["id"]}";
$db->query($s);
echo"<script> window.open('coach_dashboard.php?mes=Result deleted','_self');</script>";
?>