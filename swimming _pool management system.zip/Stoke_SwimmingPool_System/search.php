<?php
include("db.php");
$sql="SELECT * FROM events WHERE  Event_name LIKE '{$_POST["s"]}%'";

$res=$db->query($sql);
echo"<table border='1px' class='table'>
<tr>
<th> .no</th>
<th> Event Name</th>
<th> Event Place</th>
<th> Register</th>

</tr>

</table>

";



if(res->num_rows){
    $i=0;
    while($row=$res->fetch_assoc()){
        $i++;
        echo"<tr>
        <td>{$i}</td>
        <td>{$row["Event_name"]}</td>
        <td>{$row["Event_place"]}</td>
        <td><a href='ev_register.php?id={$row["id"]}'class='btnr'> Register      </td>
        
        
        
        </tr>";


    }

}



?>