<?php
include("db.php");

session_start();
 
?>


<!DOCTYPE html>
<html>
    <head>
        <title> welcome to stokepool </title>
        <link rel = "stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<?php include("navigation_bar.php");  ?>

    <img src="image/admin.jpg" width="1200px"  class="sha">
    <div id="section">
    <?php include "sidebar.php" ;?>

        
        <div id="content">
            <h3 class= text> Welcome <?php echo $_SESSION["ad_uname"]; ?></h3><br><hr><br>
            <h3> Add Event Details</h3><br>
<?php

if(isset($_POST["submit"])){


    $sql="INSERT into events(Event_name,Event_place)values('{$_POST["eventname"]}','{$_POST["sec"]}')";
    if($db->query($sql) ){
        echo"<div class = 'sucess'> Event added succesfully</div>";

    }else{

        echo"<div class = 'error'> Insert failed</div>";

    }
}
?>


            <form method="POST" action="<?php echo($_SERVER["PHP_SELF"]); ?>">
            <label>  Event name</label><br>
            <select name="eventname" required class="input2">
            <option value="">select</option>
            <option value="Stoke Swimming Gala">Stoke Swimming Gala</option>
            <option value="North Midland Swimming Race"> North Midland Swimming Race</option>
            <option value="South Wales Race"> South Wales Race</option>
            <option value="Northern Ireland Swimming Race">Northern Ireland Swimming Race</option>
            <option value="West midland Race">West midland Race</option>
            </select><br><br>
            <label> Place</label><br>
            <select name="sec" required class="input2">
            <option value="">select</option>
            <option value="Birmingham">Birmingham</option>
            <option value="South Wales">South Wales</option>
            <option value="Southampton">Southampton</option>
      </select>  <br>
      <button type="submit" class="btn" name="submit"> Add Event  </button> 

            </form>
            
</div>

<div class="tbox">
    <h3> Event Details</h3>
<?php

if(isset($_GET["mes"])){

    echo"<div class='error'>{$_GET["mes"]}</div>";
}
?>



    <table border="1px">   
<tr>
<th>s.no</th>
<th>event name</th>
<th>place</th>
<th> delete</th>




</tr>
<?php  
   $s="SELECT * FROM events";
    $res=$db->query($s);
    if($res->num_rows>0){
        $i=0;
        while($r=$res->fetch_assoc()){
            $i++;
            echo"<tr>
           <td> {$i}         </td> 
           <td>  {$r["Event_name"]}     </td> 
           <td>  {$r["Event_place"]}       </td> 
           <td><a href='ev_delete.php?id={$r["id"]}'class='btnr'> Delete       </td> 
                
            
            </tr>";


        }
    }

    ?>




    </table>




</div>





</div>


    
<div class="footer">
    <footer><p>Stoke swimming pool </p></footer>
</div>
</body>
</html>