<?php
session_start();
include("db.php");

?>





<!DOCTYPE html>
<html>
    <head>
        <title> welcome to stokepool </title>
        <link rel = "stylesheet" type="text/css" href="css/style.css">
</head>
<body class="backgr">
<?php include("navigation_bar.php");  ?>

    <img src="image/bg_image.jpg" width="100%">
    <div class="login">
        <h1 class="heading"> Admin Login </h1>
        <div class="logn">
<?php
if(isset($_POST["login"])){
    $sql="SELECT * from  admin where ad_uname='{$_POST["uname"]}' and ad_pwd='{$_POST["upass"]}'";
    $result= $db->query($sql);
    if($result->num_rows>0){
        $ar=$result->fetch_assoc();
        $_SESSION["id"]=$ar["id"];
        $_SESSION["ad_uname"]=$ar["ad_uname"];
        
        echo"<script> window.open('admin_dashboard.php','_self');</script>";

    }
    else{
        echo"<div class= 'error'>Invalid Username and Password </div>";
    }
}



?>
            <form method="POST" action="">
                <label> Username</label>
                <input type="text" name="uname" required class= "input"><br>
                <label> Password</label>
                <input type="Password" name="upass" required class="input"><br>
                <button type="submit" class="btn" name="login"> Login</button>


            </form>

</div>
</div>
<div class="footer">
    <footer><p>Stoke swimming pool </p></footer>
</div>
</body>
</html>