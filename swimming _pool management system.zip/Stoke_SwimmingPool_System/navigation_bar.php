<div class="navbar">
    <ul class="list"> 
 <b style="color:white;float:left;line-height:50px;margin-left:15px;font-family:Copper black"> Stoke Pool Management System </b> 

<?php
if(isset($_SESSION["id"])){

echo'


    <li><a href="admin_dashboard.php"> Admin Home </a> </li>
    <li><a href="admin_change_pwd.php"> Settings</a> </li>
    <li><a href="logout.php"> Logout </a> </li>
   
   

';
}
else{

    echo'


    <li><a href="index.php"> Admin </a> </li>
    <li><a href="Coach.php"> Coach</a> </li>
    <li><a href="Swimmers.php"> Swimmers</a> </li>
    <li><a href="Parents.php"> Parents</a> </li>
   
   

';


}





?>
</ul>





</div>



