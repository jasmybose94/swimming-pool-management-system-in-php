<?php
session_start();
include("db.php");
?>

<!DOCTYPE html>
<html>
    <head>
        <title> welcome to stokepool </title>
        <link rel = "stylesheet" type="text/css" href="css/style.css">
</head>
<body class="backgr">
<?php include("navigation_bar.php");  ?>
<img src="image/bg_image.jpg" width="100%">

    <div class="login">
        <h1 class="heading"> Parents Login </h1>
        <div class="logn">
            <?php
            if(isset($_POST["login"])){
                $sql="SELECT * from  parents where parent_name='{$_POST["parname"]}' and parent_pass='{$_POST["parpass"]}'";
                $result= $db->query($sql);
                if($result->num_rows>0){
                    $ar=$result->fetch_assoc();
                    $_SESSION["id"]=$ar["id"];
                    $_SESSION["parent_name"]=$ar["parent_name"];
                    
                    echo"<script> window.open('parent_dashboard.php','_self');</script>";
            
                }
                else{
                    echo"<div class= 'error'>Invalid Username and Password </div>";
                }
            }
            
            
            
            ?>


            <form method="POST" action="">
                <label> Username</label>
                <input type="text" name="parname" required class= "input"><br>
                <label> Password</label>
                <input type="Password" name="parpass" required class="input"><br>
                <button type="submit" class="btn" name="login"> Login</button><br>
                
            </form>

</div>
</div>
<div class="footer">
    <footer><p>Stoke swimming pool </p></footer>
</div>
</body>
</html>