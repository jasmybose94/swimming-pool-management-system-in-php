<?php

include"db.php";
session_start();
$s="delete from schedule where id={$_GET["id"]}";
$db->query($s);
echo"<script> window.open('swimmer_dashboard.php?mes=Schedule deleted','_self');</script>";
?>