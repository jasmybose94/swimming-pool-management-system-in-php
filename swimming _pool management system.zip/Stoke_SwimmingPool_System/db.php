<?php
$db= new mysqli("localhost","root","","spms");
if(!$db){
    echo" connection is failed";

}
?>