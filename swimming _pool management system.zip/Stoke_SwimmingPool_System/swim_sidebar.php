<div class="sidebar">
    <h3 class="text">Dashboard </h3><br><hr><br>
    <ul class="side"> 
        <?php
        
if(isset($_SESSION["id"])){
    echo'
    
    
    <li class="li"><a href="event_view.php"> View Events </a> </li>
    <li class="li"><a href="Results.php"> Gala Results </a> </li>
    <li class="li"><a href="swimpwd_change.php"> Change Password </a> </li>
    
    

    

    
    ';

}
else{


    echo'

    <li class="li"><a href=""> </a> </li>
    <li class="li"><a href="">  </a> </li>
    <li class="li"><a href="">  </a> </li>
    

     
    
    
    ';
}






        ?>






    </ul>


</div>
